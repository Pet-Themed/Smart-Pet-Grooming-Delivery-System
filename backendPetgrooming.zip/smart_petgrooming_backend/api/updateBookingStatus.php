<?php
include '../db.php';
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->booking_id) || !isset($data->new_status)) {
    echo json_encode(["success" => false, "message" => "Missing parameters"]);
    exit();
}

$booking_id = $conn->real_escape_string($data->booking_id);
$new_status = $conn->real_escape_string($data->new_status);

$sql = "UPDATE bookings SET status = '$new_status' WHERE booking_id = '$booking_id'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Status updated"]);
} else {
    echo json_encode(["success" => false, "message" => "Update failed: " . $conn->error]);
}

$conn->close();
?>