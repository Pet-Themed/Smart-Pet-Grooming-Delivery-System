<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

include '../db.php';

$response = ["success" => false, "message" => "Initialization failed"];

try {
    // Get request body (can be empty)
    $input = json_decode(file_get_contents("php://input"), true);
    
    // Fetch all deliveries with service_mode = 'Pickup & Delivery'
    $sql = "
        SELECT
            d.delivery_id,
            d.booking_id,
            d.pickup_address,
            d.pickup_time,
            d.status,
            d.service_mode,
            p.name AS pet_name
        FROM deliveries d
        JOIN bookings b ON d.booking_id = b.booking_id
        JOIN pets p ON b.pet_id = p.pet_id
        WHERE d.service_mode = 'Pickup & Delivery'
    ";
    
    $result = $conn->query($sql);
    
    if (!$result || $result->num_rows === 0) {
        $response = ["success" => false, "message" => "No pickup & delivery records found"];
    } else {
        $data = [];
        
        while ($row = $result->fetch_assoc()) {
            $data[] = [
                "delivery_id"     => strval($row["delivery_id"]),
                "booking_id"      => strval($row["booking_id"]),
                "pet_name"        => strval($row["pet_name"]),
                "pickup_address"  => strval($row["pickup_address"]),
                "pickup_time"     => strval($row["pickup_time"]),
                "status"          => strval($row["status"]),
                "service_mode"    => strval($row["service_mode"])
            ];
        }
        
        $response = ["success" => true, "data" => $data];
    }
    
} catch (Exception $e) {
    $response = [
        "success" => false,
        "message" => "Error: " . $e->getMessage()
    ];
} finally {
    echo json_encode($response);
    $conn->close();
    exit();
}