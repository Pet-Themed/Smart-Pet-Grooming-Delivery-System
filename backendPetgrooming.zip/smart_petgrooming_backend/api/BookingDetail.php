<?php
include '../db.php';

// Get JSON data
$data = json_decode(file_get_contents("php://input"));

if (!isset($data->booking_id)) {
    echo json_encode(["message" => "No booking_id provided"]);
    exit();
}

$booking_id = $data->booking_id;

$sql = "SELECT
            b.booking_id,
            p.name AS pet_name,
            s.service_type,
            b.booking_date,
            b.booking_time,
            b.status,
            d.service_mode,
            d.pickup_address,
            d.pickup_time
        FROM bookings b
        JOIN pets p ON b.pet_id = p.pet_id
        JOIN services s ON b.service_id = s.service_id
        LEFT JOIN deliveries d ON b.booking_id = d.booking_id
        WHERE b.booking_id = '$booking_id'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Format status display with service_mode
    $status_display = $row['status'];
    if ($row['service_mode']) {
        $status_display .= " (" . $row['service_mode'] . ")";
    }
    
    // Return detail
    echo json_encode([
        "booking_id" => $row['booking_id'],
        "pet_name" => $row['pet_name'],
        "service_type" => $row['service_type'],
        "booking_date" => $row['booking_date'],
        "booking_time" => $row['booking_time'],
        "status" => $status_display,
        "pickup_address" => $row['pickup_address'],
        "pickup_time" => $row['pickup_time']
    ]);
} else {
    echo json_encode(["message" => "Booking not found"]);
}

$conn->close();
?>
