<?php
include '../db.php';

// Get raw POST data
$data = json_decode(file_get_contents("php://input"));

// Validate inputs
if (!isset($data->username) || !isset($data->email) || !isset($data->password) || !isset($data->user_type)) {
    echo json_encode(["message" => "Missing required fields"]);
    exit();
}

$username = $data->username;
$password = $data->password; // Plain text (no hashing)
$email = $data->email;
$phone = isset($data->phone) ? $data->phone : null;
$address = isset($data->address) ? $data->address : null;
$user_type = $data->user_type;

// Check if email already exists
$checkEmail = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($checkEmail);

if ($result->num_rows > 0) {
    echo json_encode(["message" => "Email already registered"]);
    $conn->close();
    exit();
}

// Decide prefix based on user_type
if ($user_type === 'Pet Owner') {
    $prefix = 'O';
} else if ($user_type === 'Staff') {
    $prefix = 'S';
} else {
    echo json_encode(["message" => "Invalid user type"]);
    $conn->close();
    exit();
}

// Get last user_id with that prefix
$sql_last = "SELECT user_id FROM users WHERE user_id LIKE '$prefix%' ORDER BY user_id DESC LIMIT 1";
$result_last = $conn->query($sql_last);

if ($result_last->num_rows > 0) {
    $row = $result_last->fetch_assoc();
    $last_num = intval(substr($row['user_id'], 1));
    $new_num = $last_num + 1;
    $new_user_id = $prefix . str_pad($new_num, 3, '0', STR_PAD_LEFT);
} else {
    $new_user_id = $prefix . "001";
}

// ✅ Uncomment these to debug your values if needed
/*
 var_dump($new_user_id);
 var_dump($username);
 var_dump($email);
 var_dump($password);
 var_dump($user_type);
 var_dump($phone);
 var_dump($address);
 exit();
 */

// Insert new user
$sql = "INSERT INTO users (user_id, username, email, password, user_type, phone, address)
        VALUES ('$new_user_id', '$username', '$email', '$password', '$user_type', '$phone', '$address')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["message" => "Registration successful", "user_id" => $new_user_id]);
} else {
    echo json_encode(["message" => "Error: " . $conn->error, "sql" => $sql]);
}

$conn->close();
?>
