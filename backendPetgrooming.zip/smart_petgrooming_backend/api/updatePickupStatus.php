<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

include '../db.php';

$response = ["success" => false, "message" => "Initialization error"];

try {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);
    
    if (!isset($data['delivery_id']) || !isset($data['new_status'])) {
        throw new Exception("Missing delivery_id or new_status.");
    }
    
    $deliveryId = $conn->real_escape_string($data['delivery_id']);
    $newStatus = $conn->real_escape_string($data['new_status']);
    
    $sql = "UPDATE deliveries SET status = '$newStatus' WHERE delivery_id = '$deliveryId'";
    if ($conn->query($sql) === TRUE) {
        if ($conn->affected_rows > 0) {
            $response = [
                "success" => true,
                "message" => "Status updated successfully",
                "delivery_id" => $deliveryId,
                "new_status" => $newStatus
            ];
        } else {
            throw new Exception("No records updated - check delivery_id.");
        }
    } else {
        throw new Exception("SQL Error: " . $conn->error);
    }
} catch (Exception $e) {
    $response["success"] = false;
    $response["message"] = $e->getMessage();
} finally {
    echo json_encode($response);
    $conn->close();
    exit();
}