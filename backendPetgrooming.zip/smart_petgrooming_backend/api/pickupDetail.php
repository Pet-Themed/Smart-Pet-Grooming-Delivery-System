<?php
header("Content-Type: application/json");
include '../db.php';

$rawInput = file_get_contents("php://input");
error_log("Raw input: " . $rawInput);

$data = json_decode($rawInput);

if (
    !isset($data->booking_id) ||
    !isset($data->pickup_address) ||
    !isset($data->pickup_time)
    ) {
        echo json_encode([
            "success" => false,
            "message" => "Missing required fields. Please provide booking ID, pickup address, and pickup time."
        ]);
        exit();
    }
    
    $booking_id = $conn->real_escape_string($data->booking_id);
    $pickup_address = $conn->real_escape_string($data->pickup_address);
    $pickup_time = $conn->real_escape_string($data->pickup_time);
    
    $conn->begin_transaction();
    
    try {
        // ✅ Step 1: Get delivery record
        $checkDeliverySql = "SELECT * FROM deliveries WHERE booking_id = '$booking_id'";
        $resultDelivery = $conn->query($checkDeliverySql);
        
        if ($resultDelivery->num_rows === 0) {
            throw new Exception("Delivery record not found for this booking.");
        }
        
        $deliveryRow = $resultDelivery->fetch_assoc();
        
        if ($deliveryRow['service_mode'] !== "Pickup & Delivery") {
            throw new Exception("This booking is not for pickup & delivery service.");
        }
        
        $delivery_id = $deliveryRow['delivery_id'];
        
        // ✅ Step 2: Update delivery info
        $updateSql = "UPDATE deliveries
                  SET pickup_address = '$pickup_address',
                      pickup_time = '$pickup_time',
                      status = 'Pending'
                  WHERE delivery_id = '$delivery_id'";
        if (!$conn->query($updateSql)) {
            throw new Exception("Error updating delivery: " . $conn->error);
        }
        
        // ✅ Step 3: Update booking status
        $updateBookingSql = "UPDATE bookings SET status = 'Confirmed' WHERE booking_id = '$booking_id'";
        if (!$conn->query($updateBookingSql)) {
            throw new Exception("Error updating booking: " . $conn->error);
        }
        
        // ✅ Step 4: Get updated delivery data to return
        $getUpdatedSql = "SELECT * FROM deliveries WHERE delivery_id = '$delivery_id'";
        $resultUpdated = $conn->query($getUpdatedSql);
        $updatedDelivery = $resultUpdated->fetch_assoc();
        
        $conn->commit();
        
        echo json_encode([
            "success" => true,
            "message" => "Pickup details updated successfully!",
            "delivery" => $updatedDelivery
        ]);
        
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Transaction failed: " . $e->getMessage());
        echo json_encode([
            "success" => false,
            "message" => $e->getMessage()
        ]);
    }
    
    $conn->close();
    ?>