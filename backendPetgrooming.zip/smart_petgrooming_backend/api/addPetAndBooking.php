<?php
header("Content-Type: application/json");
include '../db.php';

// Read and decode JSON input
$data = json_decode(file_get_contents("php://input"));

// Validate required fields
if (
    !isset($data->user_id) || !isset($data->name) || !isset($data->type) ||
    !isset($data->service_type) || !isset($data->booking_date) || !isset($data->service_mode)
    ) {
        echo json_encode(["message" => "Missing required fields"]);
        exit();
    }
    
    // Get fields from JSON
    $user_id = $data->user_id;
    $name = $data->name;
    $type = $data->type;
    $breed = $data->breed ?? null;
    $age = $data->age ?? null;
    $special_notes = $data->special_notes ?? null;
    
    $service_type = $data->service_type;
    $booking_date = $data->booking_date;
    $booking_time = $data->booking_time ?? null;
    $special_instructions = $data->special_instructions ?? null;
    
    $service_mode = $data->service_mode;
    
    // Check if user exists
    $checkOwnerSql = "SELECT user_id FROM users WHERE user_id = '$user_id'";
    $resultOwner = $conn->query($checkOwnerSql);
    if ($resultOwner->num_rows === 0) {
        echo json_encode(["message" => "Owner ID not found. Please register first."]);
        exit();
    }
    
    // Get service_id from services table
    $getServiceSql = "SELECT service_id FROM services WHERE service_type = '$service_type'";
    $resultService = $conn->query($getServiceSql);
    if ($resultService->num_rows === 0) {
        echo json_encode(["message" => "Invalid service type"]);
        exit();
    }
    $serviceRow = $resultService->fetch_assoc();
    $service_id = $serviceRow['service_id'];
    
    // Validate service_mode
    if (!in_array($service_mode, ['Walk-in', 'Pickup & Delivery'])) {
        echo json_encode(["message" => "Invalid service mode"]);
        exit();
    }
    
    // Start transaction for atomic operations
    $conn->begin_transaction();
    
    try {
        // Generate new pet_id
        $getLastPetSql = "SELECT pet_id FROM pets ORDER BY pet_id DESC LIMIT 1";
        $lastPetResult = $conn->query($getLastPetSql);
        $newPetNum = ($lastPetResult->num_rows > 0)
        ? intval(substr($lastPetResult->fetch_assoc()['pet_id'], 1)) + 1
        : 1;
        $newPetId = "P" . str_pad($newPetNum, 3, "0", STR_PAD_LEFT);
        
        // Insert pet
        $insertPetSql = "INSERT INTO pets (pet_id, user_id, name, type, breed, age, special_notes)
                     VALUES ('$newPetId', '$user_id', '$name', '$type', '$breed', '$age', '$special_notes')";
        if (!$conn->query($insertPetSql)) {
            throw new Exception("Error inserting pet: " . $conn->error);
        }
        
        // Generate new booking_id
        $getLastBookingSql = "SELECT booking_id FROM bookings ORDER BY booking_id DESC LIMIT 1";
        $lastBookingResult = $conn->query($getLastBookingSql);
        $newBookingNum = ($lastBookingResult->num_rows > 0)
        ? intval(substr($lastBookingResult->fetch_assoc()['booking_id'], 1)) + 1
        : 1;
        $newBookingId = "B" . str_pad($newBookingNum, 3, "0", STR_PAD_LEFT);
        
        // Insert booking
        $insertBookingSql = "INSERT INTO bookings (booking_id, pet_id, service_id, user_id, booking_date, booking_time, status, special_instructions)
                         VALUES ('$newBookingId', '$newPetId', '$service_id', '$user_id', '$booking_date', '$booking_time', 'Pending', '$special_instructions')";
        if (!$conn->query($insertBookingSql)) {
            throw new Exception("Error inserting booking: " . $conn->error);
        }
        
        // For all service modes, create a delivery record
        $getLastDeliverySql = "SELECT delivery_id FROM deliveries ORDER BY delivery_id DESC LIMIT 1";
        $lastDeliveryResult = $conn->query($getLastDeliverySql);
        $newDeliveryNum = ($lastDeliveryResult->num_rows > 0)
        ? intval(substr($lastDeliveryResult->fetch_assoc()['delivery_id'], 1)) + 1
        : 1;
        $newDeliveryId = "D" . str_pad($newDeliveryNum, 3, "0", STR_PAD_LEFT);
        
        if ($service_mode === "Walk-in") {
            // For walk-in, create with NULL values
            $pickupSql = "INSERT INTO deliveries (delivery_id, booking_id, service_mode, status)
                      VALUES ('$newDeliveryId', '$newBookingId', '$service_mode', 'Pending')";
        } else {
            // For pickup & delivery, create with NULL pickup details (to be filled later)
            $pickupSql = "INSERT INTO deliveries (delivery_id, booking_id, service_mode, status)
                      VALUES ('$newDeliveryId', '$newBookingId', '$service_mode', 'Pending')";
        }
        
        if (!$conn->query($pickupSql)) {
            throw new Exception("Error inserting delivery: " . $conn->error);
        }
        
        // Commit transaction
        $conn->commit();
        
        // Prepare success message based on service mode
        $successMessage = "Booking created successfully!";
        if ($service_mode === "Pickup & Delivery") {
            $successMessage .= " Please provide pickup details to complete your booking.";
        } else {
            $successMessage .= " We'll see you at our location on $booking_date.";
        }
        
        echo json_encode([
            "success" => true,
            "message" => $successMessage,
            "pet_id" => $newPetId,
            "booking_id" => $newBookingId,
            "delivery_id" => $newDeliveryId,
            "service_mode" => $service_mode,
            "next_step" => ($service_mode === "Pickup & Delivery") ? "add_pickup_details" : "none"
        ]);
        
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode([
            "success" => false,
            "message" => $e->getMessage()
        ]);
    }
    
    $conn->close();
    ?>