<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

include '../db.php';

$response = ["success" => false, "message" => "Initialization failed"];

try {
    $sql = "
        SELECT
            b.booking_id,
            u.username,
            p.name AS pet_name,
            s.service_type,
            b.status AS booking_status,
            b.booking_date,
            b.booking_time,
            d.service_mode
        FROM bookings b
        JOIN users u ON b.user_id = u.user_id
        JOIN pets p ON b.pet_id = p.pet_id
        JOIN services s ON b.service_id = s.service_id
        LEFT JOIN deliveries d ON b.booking_id = d.booking_id
    ";
    
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $bookings = [];
        
        while ($row = $result->fetch_assoc()) {
            $bookings[] = [
                "booking_id"      => $row["booking_id"],
                "username"        => $row["username"],
                "pet_name"        => $row["pet_name"],
                "service_type"    => $row["service_type"],
                "booking_status"  => $row["booking_status"],
                "booking_date"    => $row["booking_date"],
                "booking_time"    => $row["booking_time"],
                "service_mode"    => $row["service_mode"] ?? "Walk-in"
            ];
        }
        
        $response = ["success" => true, "bookings" => $bookings];
    } else {
        $response = ["success" => false, "message" => "No bookings found"];
    }
} catch (Exception $e) {
    $response = ["success" => false, "message" => "Error: " . $e->getMessage()];
} finally {
    echo json_encode($response);
    $conn->close();
    exit();
}