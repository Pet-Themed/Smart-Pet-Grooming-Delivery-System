package MiniProject;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;

public class BookingStatusWindow {

    /**
     * @wbp.parser.entryPoint
     */
    public static void showBookingStatusWindow(String username, String role) {
        JFrame frame = new JFrame("🐾 Booking Status Management");
        frame.setSize(1280, 720);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.setResizable(false);

        // Background
        ImageIcon bgIcon = new ImageIcon("images/bg_status.jpg");
        Image bgImage = bgIcon.getImage().getScaledInstance(1280, 720, Image.SCALE_SMOOTH);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setBounds(0, 0, 1280, 720);

        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBounds(0, 0, 1280, 720);
        frame.getContentPane().add(layeredPane);
        layeredPane.add(backgroundLabel, Integer.valueOf(0));

        // Table Setup
        String[] columns = {"Booking ID", "Username", "Pet Name", "Service", "Status", "Date", "Time", "Mode"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(28);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 120, 1080, 400);
        layeredPane.add(scrollPane, Integer.valueOf(1));

        // Fetch Bookings from PHP API
        try {
            URL url = new URL("https://79787f35cfa7.ngrok-free.app/smart_petgrooming_backend/api/getBookingDetail.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            JSONObject jsonResponse = new JSONObject(response.toString());
            if (jsonResponse.optBoolean("success")) {
                JSONArray bookings = jsonResponse.getJSONArray("bookings");

                for (int i = 0; i < bookings.length(); i++) {
                    JSONObject b = bookings.getJSONObject(i);
                    tableModel.addRow(new String[]{
                        b.optString("booking_id"),
                        b.optString("username"),
                        b.optString("pet_name"),
                        b.optString("service_type"),
                        b.optString("booking_status"),
                        b.optString("booking_date"),
                        b.optString("booking_time"),
                        b.optString("service_mode")
                    });
                }
            } else {
                JOptionPane.showMessageDialog(frame, "No bookings found.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "❌ Failed to fetch booking data.");
        }

        // Status Dropdown
        JComboBox<String> statusBox = new JComboBox<>(new String[]{"Pending", "Confirmed", "In Progress", "Completed", "Cancelled"});
        statusBox.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        statusBox.setBounds(500, 540, 180, 35);
        layeredPane.add(statusBox, Integer.valueOf(1));

        // Update Status Button
        JButton updateButton = new JButton("Update Status");
        updateButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        updateButton.setBounds(700, 540, 180, 35);
        layeredPane.add(updateButton, Integer.valueOf(1));

        updateButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                String bookingId = (String) table.getValueAt(selectedRow, 0);
                String newStatus = (String) statusBox.getSelectedItem();

                try {
                    URL url = new URL("https://79787f35cfa7.ngrok-free.app/smart_petgrooming_backend/api/updateBookingStatus.php");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    conn.setDoOutput(true);

                    String jsonPayload = String.format(
                        "{\"booking_id\":\"%s\", \"new_status\":\"%s\"}",
                        escapeJson(bookingId), escapeJson(newStatus)
                    );

                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
                    }

                    int responseCode = conn.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        table.setValueAt(newStatus, selectedRow, 4); // Update status in table
                        JOptionPane.showMessageDialog(frame, "✅ Status updated successfully!");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Server error: " + responseCode);
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a booking to update.");
            }
        });

        // Back Button
        JButton backButton = new JButton("← Back to Dashboard");
        backButton.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        backButton.setBounds(100, 540, 200, 35);
        layeredPane.add(backButton, Integer.valueOf(1));

        backButton.addActionListener(e -> {
            frame.dispose();
            StaffDashboardWindow.showDashboard(username); // Adjust if needed
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r");
    }
}
