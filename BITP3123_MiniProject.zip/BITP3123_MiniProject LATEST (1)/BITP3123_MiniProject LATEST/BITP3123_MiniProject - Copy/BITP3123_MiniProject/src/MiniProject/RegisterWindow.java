package MiniProject;

import javax.swing.*;
import java.awt.*;
import java.io.OutputStream;
import java.net.URL;
import java.net.HttpURLConnection;
public class RegisterWindow {

    public static void showRegisterWindow() {
        JFrame frame = new JFrame("🐾 Pet Grooming - Register");
        frame.setSize(1280, 720);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        // ===== Background Image =====
        ImageIcon bgIcon = new ImageIcon("images/bg_register.jpg");
        Image bgImage = bgIcon.getImage().getScaledInstance(1280, 720, Image.SCALE_SMOOTH);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setBounds(0, 0, 1280, 720);

        // ===== Layered Pane =====
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBounds(0, 0, 1280, 720);
        frame.add(layeredPane);
        layeredPane.add(backgroundLabel, Integer.valueOf(0));

        Font labelFont = new Font("Segoe UI", Font.PLAIN, 16);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 16);

        JLabel titleLabel = new JLabel("Create Your Account");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setBounds(510, 90, 300, 30);
        layeredPane.add(titleLabel, Integer.valueOf(1));

        int labelX = 420, fieldX = 530, startY = 140, gapY = 40;

        // Form fields
        JTextField userText = new JTextField();
        JPasswordField passText = new JPasswordField();
        JTextField emailText = new JTextField();
        JTextField phoneText = new JTextField();
        JTextField addressText = new JTextField();
        JComboBox<String> roleBox = new JComboBox<>(new String[]{"Pet Owner", "Staff"});

        String[] labels = {"Username:", "Password:", "Email:", "Phone:", "Address:", "User Type:"};
        JComponent[] fields = {userText, passText, emailText, phoneText, addressText, roleBox};

        for (int i = 0; i < labels.length; i++) {
            JLabel label = new JLabel(labels[i]);
            label.setFont(labelFont);
            label.setBounds(labelX, startY + i * gapY, 100, 25);
            layeredPane.add(label, Integer.valueOf(1));

            JComponent field = fields[i];
            field.setFont(fieldFont);
            field.setBounds(fieldX, startY + i * gapY, 240, 28);
            layeredPane.add(field, Integer.valueOf(1));
        }

        JButton registerButton = new JButton("Register");
        registerButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        registerButton.setBounds(530, startY + gapY * 6 + 10, 130, 35);
        layeredPane.add(registerButton, Integer.valueOf(1));

        // ===== Button Logic =====
        registerButton.addActionListener(e -> {
            String username = userText.getText().trim();
            String password = new String(passText.getPassword()).trim();
            String email = emailText.getText().trim();
            String phone = phoneText.getText().trim();
            String address = addressText.getText().trim();
            String userType = roleBox.getSelectedItem().toString();

            if (username.isEmpty() || password.isEmpty() || email.isEmpty() || phone.isEmpty() || address.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.");
                return;
            }

            try {
                URL url = new URL("https://79787f35cfa7.ngrok-free.app/smart_petgrooming_backend/api/registerOwner.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");

                String jsonData = String.format(
                    "{\"username\":\"%s\",\"password\":\"%s\",\"email\":\"%s\",\"phone\":\"%s\",\"address\":\"%s\",\"user_type\":\"%s\"}",
                    escapeJson(username),
                    escapeJson(password),
                    escapeJson(email),
                    escapeJson(phone),
                    escapeJson(address),
                    escapeJson(userType)
                );

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(jsonData.getBytes("utf-8"));
                }

                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    JOptionPane.showMessageDialog(frame, "Registration successful! You can now log in.");
                    frame.dispose();
                    LoginWindow.main(null);
                } else {
                    JOptionPane.showMessageDialog(frame, "Registration failed. Server error: " + responseCode);
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error connecting to server: " + ex.getMessage());
            }
        });

        frame.setVisible(true);
    }

    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}