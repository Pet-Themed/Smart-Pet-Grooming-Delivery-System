package MiniProject;

import javax.swing.*;
import java.awt.*;

public class StatusWindow {

    public static void showStatusWindow(String petName, String service, String status, String appointmentDate, String appointmentTime) {
        JFrame frame = new JFrame("🐾 Booking Status");
        frame.setSize(1280, 720);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        // ===== Background Image =====
        ImageIcon bgIcon = new ImageIcon("images/bg_status.jpg");
        Image bgImage = bgIcon.getImage().getScaledInstance(1280, 720, Image.SCALE_SMOOTH);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setBounds(0, 0, 1280, 720);

        // ===== Layered Pane =====
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBounds(0, 0, 1280, 720);
        frame.add(layeredPane);
        layeredPane.add(backgroundLabel, Integer.valueOf(0));

        // ===== Cat Icon =====
        ImageIcon catIcon = new ImageIcon(new ImageIcon("images/cat.png").getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH));
        JLabel catLabel = new JLabel(catIcon);
        catLabel.setBounds(590, 50, 100, 100);
        layeredPane.add(catLabel, Integer.valueOf(1));

        // ===== Title Label =====
        JLabel statusLabel = new JLabel("Your Booking Details:");
        statusLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        statusLabel.setForeground(Color.WHITE);
        statusLabel.setBounds(500, 170, 300, 30);
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        layeredPane.add(statusLabel, Integer.valueOf(1));

        // ===== Booking Info Text Area =====
        JTextArea statusArea = new JTextArea();
        statusArea.setBounds(490, 220, 300, 160);
        statusArea.setFont(new Font("Monospaced", Font.PLAIN, 16));
        statusArea.setBackground(new Color(255, 255, 255, 200)); // Semi-transparent white
        statusArea.setEditable(false);
        statusArea.setText(
            "🐾 Pet Name : " + petName +
            "\n🛁 Service : " + service +
            "\n📅 Date    : " + appointmentDate +
            "\n⏰ Time    : " + appointmentTime +
            "\n✅ Status  : " + status
        );
        layeredPane.add(statusArea, Integer.valueOf(1));

        // ===== Exit Button =====
        JButton exitButton = new JButton("Exit");
        exitButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        exitButton.setBounds(590, 410, 100, 35);
        layeredPane.add(exitButton, Integer.valueOf(1));

        exitButton.addActionListener(e -> frame.dispose());

        frame.setLocationRelativeTo(null); // Center on screen
        frame.setVisible(true);
    }
}