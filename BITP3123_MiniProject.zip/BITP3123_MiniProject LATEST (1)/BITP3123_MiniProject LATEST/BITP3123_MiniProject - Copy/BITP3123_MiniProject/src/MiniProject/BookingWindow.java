package MiniProject;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import com.toedter.calendar.JDateChooser;
import org.json.JSONObject;

public class BookingWindow {

    public static void showBookingWindow(String userId) {
        JFrame frame = new JFrame("🐾 Book Grooming Service");
        frame.setSize(1280, 720);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);

        ImageIcon bgIcon = new ImageIcon("images/bg_booking.jpg");
        Image bgImage = bgIcon.getImage().getScaledInstance(1280, 720, Image.SCALE_SMOOTH);
        JLabel background = new JLabel(new ImageIcon(bgImage));
        background.setBounds(0, 0, 1280, 720);

        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBounds(0, 0, 1280, 720);
        frame.getContentPane().add(layeredPane);
        layeredPane.add(background, Integer.valueOf(0));

        int xBase = 700;

        JLabel titleLabel = new JLabel("Pet Grooming Booking");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        titleLabel.setBounds(xBase, 30, 300, 30);
        layeredPane.add(titleLabel, Integer.valueOf(1));

        String[] labels = {
            "Pet Name:", "Pet Type:", "Breed:", "Age:",
            "Special Notes:", "Service Type:", "Appointment Date:", "Appointment Time:", "Service Mode:"
        };

        int y = 80, height = 30;
        for (String label : labels) {
            JLabel formLabel = new JLabel(label);
            formLabel.setBounds(xBase, y, 150, height);
            layeredPane.add(formLabel, Integer.valueOf(1));
            y += 40;
        }

        JTextField petNameText = new JTextField();
        petNameText.setBounds(xBase + 150, 80, 250, height);
        layeredPane.add(petNameText, Integer.valueOf(1));

        String[] petTypes = {"Dog", "Cat", "Other"};
        JComboBox<String> petTypeBox = new JComboBox<>(petTypes);
        petTypeBox.setBounds(xBase + 150, 120, 250, height);
        layeredPane.add(petTypeBox, Integer.valueOf(1));

        JTextField breedText = new JTextField();
        breedText.setBounds(xBase + 150, 160, 250, height);
        layeredPane.add(breedText, Integer.valueOf(1));

        JTextField ageText = new JTextField();
        ageText.setBounds(xBase + 150, 200, 250, height);
        layeredPane.add(ageText, Integer.valueOf(1));

        JTextField notesText = new JTextField();
        notesText.setBounds(xBase + 150, 240, 250, height);
        layeredPane.add(notesText, Integer.valueOf(1));

        String[] services = {"Basic Grooming", "Full Grooming"};
        JComboBox<String> serviceBox = new JComboBox<>(services);
        serviceBox.setBounds(xBase + 150, 280, 250, height);
        layeredPane.add(serviceBox, Integer.valueOf(1));

        JDateChooser dateChooser = new JDateChooser();
        dateChooser.setBounds(xBase + 150, 320, 250, height);
        layeredPane.add(dateChooser, Integer.valueOf(1));

        String[] times = {"10:00 AM", "11:00 AM", "12:00 PM", "2:00 PM", "3:00 PM", "4:00 PM"};
        JComboBox<String> timeBox = new JComboBox<>(times);
        timeBox.setBounds(xBase + 150, 360, 250, height);
        layeredPane.add(timeBox, Integer.valueOf(1));

        JRadioButton walkInBtn = new JRadioButton("Walk-in");
        JRadioButton pickupBtn = new JRadioButton("Pickup & Delivery");
        walkInBtn.setBounds(xBase + 150, 400, 100, height);
        pickupBtn.setBounds(xBase + 250, 400, 150, height);
        walkInBtn.setOpaque(false);
        pickupBtn.setOpaque(false);

        ButtonGroup modeGroup = new ButtonGroup();
        modeGroup.add(walkInBtn);
        modeGroup.add(pickupBtn);

        layeredPane.add(walkInBtn, Integer.valueOf(1));
        layeredPane.add(pickupBtn, Integer.valueOf(1));

        JButton bookButton = new JButton("Book Now");
        bookButton.setBounds(xBase + 150, 460, 150, 35);
        layeredPane.add(bookButton, Integer.valueOf(1));

        bookButton.addActionListener(e -> {
            String petName = petNameText.getText().trim();
            String petType = (String) petTypeBox.getSelectedItem();
            String breed = breedText.getText().trim();
            String age = ageText.getText().trim();
            String notes = notesText.getText().trim();
            String service = (String) serviceBox.getSelectedItem();
            String appointmentDate = (dateChooser.getDate() != null)
                    ? new SimpleDateFormat("yyyy-MM-dd").format(dateChooser.getDate()) : "";
            String appointmentTime = (String) timeBox.getSelectedItem();
            String serviceMode = walkInBtn.isSelected() ? "Walk-in" : (pickupBtn.isSelected() ? "Pickup & Delivery" : "");

            if (petName.isEmpty() || breed.isEmpty() || age.isEmpty() || appointmentDate.isEmpty() || serviceMode.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all required fields and select service mode.");
                return;
            }

            try {
                URL url = new URL("https://79787f35cfa7.ngrok-free.app/smart_petgrooming_backend/api/addPetAndBooking.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);

                String json = String.format(
                    "{\"user_id\":\"%s\",\"name\":\"%s\",\"type\":\"%s\",\"breed\":\"%s\",\"age\":\"%s\",\"special_notes\":\"%s\",\"service_type\":\"%s\",\"booking_date\":\"%s\",\"booking_time\":\"%s\",\"service_mode\":\"%s\"}",
                    escapeJson(userId), escapeJson(petName), escapeJson(petType), escapeJson(breed), escapeJson(age),
                    escapeJson(notes), escapeJson(service), escapeJson(appointmentDate), escapeJson(appointmentTime), escapeJson(serviceMode)
                );

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }

                InputStream is = conn.getInputStream();
                StringBuilder response = new StringBuilder();
                int ch;
                while ((ch = is.read()) != -1) response.append((char) ch);

                JSONObject jsonResponse = new JSONObject(response.toString());
                if (jsonResponse.optBoolean("success")) {
                    String petId = jsonResponse.optString("pet_id", "N/A");
                    String bookingId = jsonResponse.optString("booking_id", "N/A");

                    JOptionPane.showMessageDialog(frame,
                        "✅ Booking Successful!\nPet ID: " + petId + "\nBooking ID: " + bookingId);

                    frame.dispose();

                    if (serviceMode.equals("Pickup & Delivery")) {
                        PickupDetailsWindow.showPickupWindow(bookingId, petName, service, appointmentDate, appointmentTime);
                    } else {
                        StatusWindow.showStatusWindow(petName, service, "Pending", appointmentDate, appointmentTime);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "❌ Error: " + jsonResponse.optString("message"));
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r");
    }
}
