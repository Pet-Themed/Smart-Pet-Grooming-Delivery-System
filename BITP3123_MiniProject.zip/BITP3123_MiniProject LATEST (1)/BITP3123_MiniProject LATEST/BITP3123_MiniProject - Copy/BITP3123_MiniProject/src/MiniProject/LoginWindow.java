package MiniProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class LoginWindow {

    public static void main(String[] args) {
        showLoginWindow();
    }

    public static void showLoginWindow() {
        JFrame frame = new JFrame("🐾 Pet Grooming Login");
        frame.setSize(1280, 720);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        ImageIcon backgroundIcon = new ImageIcon("images/bg_petgrooming.jpg");
        Image backgroundImg = backgroundIcon.getImage().getScaledInstance(1280, 720, Image.SCALE_SMOOTH);
        JLabel backgroundLabel = new JLabel(new ImageIcon(backgroundImg));
        backgroundLabel.setBounds(0, 0, 1280, 720);

        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBounds(0, 0, 1280, 720);
        frame.add(layeredPane);
        layeredPane.add(backgroundLabel, Integer.valueOf(0));

        int xBase = 490;
        int yBase = 380;

        JLabel lblTitle = new JLabel("Smart Pet Grooming");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setBounds(xBase + 40, yBase, 300, 30);
        layeredPane.add(lblTitle, Integer.valueOf(1));

        JLabel labelUser = new JLabel("Username:");
        labelUser.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        labelUser.setBounds(xBase, yBase + 50, 100, 25);
        layeredPane.add(labelUser, Integer.valueOf(1));

        JTextField userText = new JTextField();
        userText.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        userText.setBounds(xBase + 100, yBase + 50, 180, 30);
        layeredPane.add(userText, Integer.valueOf(1));

        JLabel labelPass = new JLabel("Password:");
        labelPass.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        labelPass.setBounds(xBase, yBase + 100, 100, 25);
        layeredPane.add(labelPass, Integer.valueOf(1));

        JPasswordField passText = new JPasswordField();
        passText.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        passText.setBounds(xBase + 100, yBase + 100, 180, 30);
        layeredPane.add(passText, Integer.valueOf(1));

        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        loginButton.setBounds(xBase + 80, yBase + 150, 120, 35);
        layeredPane.add(loginButton, Integer.valueOf(1));

        JLabel registerLabel = new JLabel("<HTML><U>Don't have an account? Register here</U></HTML>");
        registerLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        registerLabel.setForeground(Color.BLUE);
        registerLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        registerLabel.setBounds(xBase - 10, yBase + 200, 300, 30);
        layeredPane.add(registerLabel, Integer.valueOf(1));

        loginButton.addActionListener(e -> {
            String username = userText.getText().trim();
            String password = new String(passText.getPassword()).trim();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter username and password.");
                return;
            }

            try {
                URL url = new URL("https://79787f35cfa7.ngrok-free.app/smart_petgrooming_backend/api/login.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");

                String jsonInput = String.format(
                        "{\"username\":\"%s\",\"password\":\"%s\"}",
                        escapeJson(username), escapeJson(password)
                );

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(jsonInput.getBytes("utf-8"));
                }

                int responseCode = conn.getResponseCode();
                InputStream is = (responseCode >= 200 && responseCode < 300)
                        ? conn.getInputStream()
                        : conn.getErrorStream();

                StringBuilder response = new StringBuilder();
                try (Scanner scanner = new Scanner(is)) {
                    while (scanner.hasNextLine()) {
                        response.append(scanner.nextLine());
                    }
                }

                String json = response.toString();

                if (json.contains("\"status\":\"success\"")) {
                    String user_id = extractJsonValue(json, "user_id");
                    String user_type;

                    if (user_id.startsWith("O")) {
                        user_type = "Pet Owner";
                        JOptionPane.showMessageDialog(frame, "Login successful as Pet Owner!");
                        frame.dispose();
                        BookingWindow.showBookingWindow(user_id); // Pass actual user_id
                    } else if (user_id.startsWith("S")) {
                        user_type = "Staff";
                        JOptionPane.showMessageDialog(frame, "Login successful as Staff!");
                        frame.dispose();
                        StaffDashboardWindow.showDashboard(user_id);
                    } else {
                        user_type = "Unknown";
                        JOptionPane.showMessageDialog(frame, "Unknown user role.");
                    }

                } else {
                    String message = extractJsonValue(json, "message");
                    if (message.isEmpty()) message = "Invalid credentials or server error.";
                    JOptionPane.showMessageDialog(frame, "Login failed: " + message, "Error", JOptionPane.ERROR_MESSAGE);
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
            }
        });

        registerLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                RegisterWindow.showRegisterWindow();
            }
        });

        frame.setVisible(true);
    }

    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String extractJsonValue(String json, String key) {
        String target = "\"" + key + "\":\"";
        int start = json.indexOf(target);
        if (start == -1) return "";
        start += target.length();
        int end = json.indexOf("\"", start);
        if (end == -1) return "";
        return json.substring(start, end);
    }
}