package MiniProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StaffDashboardWindow {

    public static void showDashboard(String username) {
        JFrame frame = new JFrame("🐾 Staff Dashboard");
        frame.setSize(1280, 720);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        // ===== Background Image =====
        ImageIcon bgIcon = new ImageIcon("images/bg_staff.jpg"); // Your image path
        Image bgImage = bgIcon.getImage().getScaledInstance(1280, 720, Image.SCALE_SMOOTH);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setBounds(0, 0, 1280, 720);

        // ===== Layered Pane =====
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBounds(0, 0, 1280, 720);
        frame.add(layeredPane);
        layeredPane.add(backgroundLabel, Integer.valueOf(0));

        // ===== Welcome Label =====
        JLabel welcomeLabel = new JLabel("Welcome, " + username + "!");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        welcomeLabel.setBounds(0, 150, 1280, 40);
        layeredPane.add(welcomeLabel, Integer.valueOf(1));

        // ===== Buttons =====
        Font buttonFont = new Font("Segoe UI", Font.PLAIN, 20);

        JButton viewBookingsBtn = new JButton("Manage Booking Status");
        viewBookingsBtn.setFont(buttonFont);
        viewBookingsBtn.setBounds(490, 220, 300, 50);
        layeredPane.add(viewBookingsBtn, Integer.valueOf(1));

        JButton deliveryBtn = new JButton("View Pickup Assignments");
        deliveryBtn.setFont(buttonFont);
        deliveryBtn.setBounds(490, 300, 300, 50);
        layeredPane.add(deliveryBtn, Integer.valueOf(1));

        // ===== Exit Button =====
        JButton btnExit = new JButton("X");
        btnExit.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnExit.setBackground(new Color(255, 0, 0));
        btnExit.setForeground(Color.WHITE);
        btnExit.setFocusPainted(false);
        btnExit.setBounds(1200, 20, 50, 30);
        layeredPane.add(btnExit, Integer.valueOf(1));

        // ===== Action Listeners =====
        btnExit.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                frame,
                "Are you sure you want to exit?",
                "Exit Confirmation",
                JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });

        viewBookingsBtn.addActionListener(e -> {
            frame.dispose();
            BookingStatusWindow.showBookingStatusWindow(username, "Staff");
        });

        deliveryBtn.addActionListener(e -> {
            frame.dispose();
            PickupAssignedWindow.showAssignedPickupWindow(username);
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}