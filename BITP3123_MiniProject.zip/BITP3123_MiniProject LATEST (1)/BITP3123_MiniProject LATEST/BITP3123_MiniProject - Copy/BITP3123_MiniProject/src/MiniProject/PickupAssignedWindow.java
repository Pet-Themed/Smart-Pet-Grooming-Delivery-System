package MiniProject;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;

public class PickupAssignedWindow {

    public static void showAssignedPickupWindow(String username) {
        JFrame frame = new JFrame("📋 Assigned Pickup Tasks");
        frame.setSize(1280, 720);
        frame.setUndecorated(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        // ===== Background Image =====
        ImageIcon bgIcon = new ImageIcon("images/bg_status.jpg");
        Image bgImage = bgIcon.getImage().getScaledInstance(1280, 720, Image.SCALE_SMOOTH);
        JLabel bgLabel = new JLabel(new ImageIcon(bgImage));
        bgLabel.setBounds(0, 0, 1280, 720);

        // ===== Layered Pane =====
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBounds(0, 0, 1280, 720);
        frame.add(layeredPane);
        layeredPane.add(bgLabel, Integer.valueOf(0));

        // ===== Main Panel =====
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBounds(300, 100, 680, 450);
        mainPanel.setBackground(new Color(255, 255, 255, 220));
        layeredPane.add(mainPanel, Integer.valueOf(1));

        JLabel titleLabel = new JLabel("Assigned Pickup Bookings");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBounds(190, 20, 300, 30);
        mainPanel.add(titleLabel);

        // 🟨 Includes delivery_id (hidden)
        String[] columnNames = {"Delivery ID", "Booking ID", "Pet Name", "Address", "Pickup Time", "Status"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        table.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 70, 580, 180);
        mainPanel.add(scrollPane);

        // ✅ Fetch pickup data from backend
        try {
            URL url = new URL("https://79787f35cfa7.ngrok-free.app/smart_petgrooming_backend/api/getPickupDetail.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) response.append(line);
            in.close();

            JSONObject json = new JSONObject(response.toString());
            if (json.getBoolean("success")) {
                JSONArray data = json.getJSONArray("data");
                for (int i = 0; i < data.length(); i++) {
                    JSONObject pickup = data.getJSONObject(i);
                    String deliveryId = pickup.getString("delivery_id");
                    String bookingId = pickup.getString("booking_id");
                    String petName = pickup.getString("pet_name");
                    String pickupAddress = pickup.getString("pickup_address");
                    String pickupTime = pickup.getString("pickup_time");
                    String status = pickup.getString("status");
                    model.addRow(new String[]{deliveryId, bookingId, petName, pickupAddress, pickupTime, status});
                }
            } else {
                JOptionPane.showMessageDialog(frame, "No pickups found.");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error fetching pickup details: " + e.getMessage());
            e.printStackTrace();
        }

        JLabel statusLabel = new JLabel("Set Status:");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        statusLabel.setBounds(130, 270, 100, 25);
        mainPanel.add(statusLabel);

        String[] statuses = {"Pending", "Confirmed", "In Progress", "Completed", "Cancelled"};
        JComboBox<String> statusCombo = new JComboBox<>(statuses);
        statusCombo.setBounds(220, 270, 160, 25);
        mainPanel.add(statusCombo);

        JButton updateButton = new JButton("Update Status");
        updateButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        updateButton.setBounds(400, 270, 150, 30);
        mainPanel.add(updateButton);

        JButton closeButton = new JButton("Back");
        closeButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        closeButton.setBounds(290, 330, 100, 30);
        mainPanel.add(closeButton);

        updateButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(frame, "Please select a booking.");
                return;
            }

            String deliveryId = model.getValueAt(row, 0).toString(); // 🟨 delivery_id
            String newStatus = (String) statusCombo.getSelectedItem();

            try {
                URL url = new URL("https://79787f35cfa7.ngrok-free.app/smart_petgrooming_backend/api/updatePickupStatus.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                String json = String.format("{\"delivery_id\":\"%s\", \"new_status\":\"%s\"}",
                        escapeJson(deliveryId), escapeJson(newStatus));

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }

                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    model.setValueAt(newStatus, row, 5); // update status column
                    JOptionPane.showMessageDialog(frame, "Status updated to '" + newStatus + "'");
                } else {
                    JOptionPane.showMessageDialog(frame, "Server error: " + responseCode);
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Update failed: " + ex.getMessage());
            }
        });

        closeButton.addActionListener(e -> {
            frame.dispose();
            StaffDashboardWindow.showDashboard(username);
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r");
    }
}
