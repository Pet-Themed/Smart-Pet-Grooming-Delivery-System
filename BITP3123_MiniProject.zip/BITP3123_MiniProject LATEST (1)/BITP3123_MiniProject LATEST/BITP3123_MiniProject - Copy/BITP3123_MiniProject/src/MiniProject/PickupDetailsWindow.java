package MiniProject;

import javax.swing.*;
import java.awt.*;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class PickupDetailsWindow {

    public static void showPickupWindow(String bookingId, String petName, String service, String appointmentDate, String appointmentTime) {
        JFrame frame = new JFrame("🐾 Pickup & Delivery Details");
        frame.setSize(1280, 720);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        // ===== Background Image =====
        ImageIcon bgIcon = new ImageIcon("images/bg_status.jpg");
        Image bgImage = bgIcon.getImage().getScaledInstance(1280, 720, Image.SCALE_SMOOTH);
        JLabel backgroundLabel = new JLabel(new ImageIcon(bgImage));
        backgroundLabel.setBounds(0, 0, 1280, 720);

        // ===== Layered Pane =====
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setBounds(0, 0, 1280, 720);
        frame.add(layeredPane);
        layeredPane.add(backgroundLabel, Integer.valueOf(0));

        // ===== Form Panel =====
        JPanel formPanel = new JPanel();
        formPanel.setBounds(450, 170, 380, 300);
        formPanel.setLayout(null);
        formPanel.setBackground(new Color(255, 255, 255, 220));
        layeredPane.add(formPanel, Integer.valueOf(1));

        JLabel title = new JLabel("Enter Pickup Address");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        title.setBounds(50, 20, 280, 30);
        formPanel.add(title);

        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        addressLabel.setBounds(30, 70, 80, 25);
        formPanel.add(addressLabel);

        JTextField addressText = new JTextField();
        addressText.setBounds(120, 70, 220, 25);
        formPanel.add(addressText);

        JLabel pickupTimeLabel = new JLabel("Pickup Time:");
        pickupTimeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        pickupTimeLabel.setBounds(30, 115, 100, 25);
        formPanel.add(pickupTimeLabel);

        String[] times = {"8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "1:00 PM", "2:00 PM"};
        JComboBox<String> pickupTimeBox = new JComboBox<>(times);
        pickupTimeBox.setBounds(140, 115, 200, 25);
        formPanel.add(pickupTimeBox);

        JButton confirmBtn = new JButton("Confirm Booking");
        confirmBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        confirmBtn.setBounds(100, 190, 180, 40);
        formPanel.add(confirmBtn);

        confirmBtn.addActionListener(e -> {
            String pickupAddress = addressText.getText().trim();
            String selectedPickupTime = (String) pickupTimeBox.getSelectedItem();

            if (pickupAddress.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter your pickup address.");
                return;
            }

            try {
                // ✅ Corrected URL (removed space)
                URL url = new URL("https://79787f35cfa7.ngrok-free.app/smart_petgrooming_backend/api/pickupDetail.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);

                // ✅ JSON payload that matches PHP backend
                String jsonPayload = String.format(
                    "{" +
                        "\"booking_id\":\"%s\"," +
                        "\"pickup_address\":\"%s\"," +
                        "\"pickup_time\":\"%s\"" +
                    "}",
                    escapeJson(bookingId), escapeJson(pickupAddress), escapeJson(selectedPickupTime)
                );

                // 🔄 Send the JSON payload
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
                }

                int responseCode = conn.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    JOptionPane.showMessageDialog(frame, "Pickup details submitted successfully!");
                    frame.dispose();
                    StatusWindow.showStatusWindow(petName, service, "Pending", appointmentDate, appointmentTime);
                } else {
                    JOptionPane.showMessageDialog(frame, "Server error: " + responseCode);
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Error sending pickup details: " + ex.getMessage());
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // Escape special characters in JSON
    private static String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r");
    }
}
